-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2024 at 04:58 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customkeyboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `username`, `password`) VALUES
(3, 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `customerlogin`
--

CREATE TABLE `customerlogin` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `pp` varchar(255) NOT NULL DEFAULT 'default-pp.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerlogin`
--

INSERT INTO `customerlogin` (`id`, `fname`, `username`, `password`, `pp`) VALUES
(1, 'Dino', 'Greymon', '$2y$10$EvlgGoJoq7oQGwcoFx3e0.Ok/kge9gpthD5Bh8WFtDCIJbDBJDQ56', 'Greymon6609e66e7a2e16.14476236.jpg'),
(2, 'Mameo Ong', 'mr.bone', '$2y$10$e4Xsb3dTx3.3dlRPCJzmvO4KPqx1luXF0B6Ofn16PyYfW.WrXKy8y', 'mr.bone660a4147a72425.69810001.png'),
(3, 'Mameo Ongff', 'mr.boneff', '$2y$10$Kmd4mnKe4JoMjlYL49vpyuaeKsg.b/U3iY3XNLYovmRfSM2io8.yO', 'mr.boneff660a4181b635b8.82616113.jpg'),
(4, 'Dino', 'digimon', '$2y$10$RkMieLy.iM1ITeWedpFpf.G4DiwlDqvIcHL6C3IxRorcFfcOO1c/C', 'digimon660a424772e669.18017239.jpg'),
(5, 'AdminFullName', 'AdminUsername', '$2y$10$xnwU520M.AuIbWuWvALMDu7MNo6ymxFVzGdEuGtuElqzJSGYrkvHW', 'AdminUsername660a43a8211012.83617745.jpg'),
(6, 'Gabumon', 'Gabunigga', '$2y$10$9eM9FSpOTTuba.nhaZYDv.d2BucyXPNxtREKRe/70FmnlI/j0LeS6', 'Gabunigga660b42323a03d9.98505151.png'),
(7, 'CustomerFullName', 'CustomerUsername', '$2y$10$TIP2GFFsoS9AGN/0xUy5se.7jtWZoBa5MBlRdXdlWhoUM4BRuqDte', 'CustomerUsername660bca45297a44.78500475.png'),
(8, 'a', 'a', 'a', 'default-pp.png');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `productName`, `body`, `price`, `image`) VALUES
(2, 'SilverRGB', 'A keyboard that combines the latest technology with a classic, timeless design.', '100.89', 'SilverRGB.jpg'),
(3, 'RaijinTouch', 'Explore a new dimension of typing with RaijinTouch.', '199.99', 'YameteKudasai.jpg'),
(5, 'NovaFlex', 'Embrace flexibility and adaptability with NovaFlex. ', '120.99', 'NovaFlex.jpg'),
(6, 'GGV12', 'Illuminate your typiasas experience with ChromaTap.', '127.88', 'ChromaTap.png'),
(7, 'GGA', 'Keyboard not Tigers', '123.99', '660bf93ebc0786.42751649.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `customerlogin`
--
ALTER TABLE `customerlogin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customerlogin`
--
ALTER TABLE `customerlogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
