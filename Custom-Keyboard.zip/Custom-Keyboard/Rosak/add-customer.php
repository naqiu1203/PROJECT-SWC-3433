<?php
include('session_m.php');
?>
<?php
$user_check=$_SESSION['login_user2'];
$sql = "SELECT * FROM customerlogin";
$result = mysqli_query($conn, $sql);
	
		$username =  $_REQUEST['username'];
        $password = $_REQUEST['password'];
        $email =  $_REQUEST['email'];
        $contact = $_REQUEST['contact'];
		$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    	$picture_path = htmlspecialchars($target_file);

	
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "<script>File is an image - " . $check["mime"] . ".</script>";
    $uploadOk = 1;
  } else {
    echo "<script>File is not an image.</script>";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "<script>Sorry, file already exists.</script>";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "<script>Sorry, your file is too large.</script>";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "<script>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</script>";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "<script>Sorry, your file was not uploaded.</script>";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	  
$query = "INSERT INTO customerlogin(username,password,email,contact,picture_path) VALUES('" . $username . "','" . $password . "','" . $email . "','" . $contact . "','" . $picture_path . "')";
$success = $conn->query($query);	
	
	
echo "
        <script>
            alert('Registered Successfully');
            window.location.href = 'login-page.php';
        </script>
        ";	 
	  
  } else {
    echo "<script>Sorry, there was an error uploading your file.</script>";
  }
}

?>