<?php 
 
// Starting the session, necessary
// for using session variables
session_start();
  
// Declaring and hoisting the variables
$username = "";
$email = "";
$contact = "";
$picture_path = "";
$errors = array(); 
$_SESSION['success'] = "";
  
// DBMS connection code -> hostname,
// username, password, database name
$db = mysqli_connect('localhost', 'root', '', 'customkeyboard');
  
// Registration code
if (isset($_POST['submit'])) {
  
    // Receiving the values entered and storing
    // in the variables
    // Data sanitization is done to prevent
    // SQL injections
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
	$contact = mysqli_real_escape_string($db, $_POST['contact']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $picture_path = mysqli_real_escape_string($target_file);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
  
    // Ensuring that the user has not left any input field blank
    // error messages will be displayed for every blank input
    if (empty($username)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($password)) { array_push($errors, "Password is required"); }
	if (empty($contact)) { array_push($errors, "Contact is required"); }
	if (empty($picture_path)) { array_push($errors, "Picture is required"); }

	// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "<script>File is an image - " . $check["mime"] . ".</script>";
    $uploadOk = 1;
  } else {
    echo "<script>File is not an image.</script>";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "<script>Sorry, file already exists.</script>";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "<script>Sorry, your file is too large.</script>";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "<script>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</script>";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "<script>Sorry, your file was not uploaded.</script>";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	echo  "<script>
            alert('Upload Successfully');
        	</script>"; 
	} else {
    echo "<script>Sorry, there was an error uploading your file.</script>";
  }
}
    
  
    // If the form is error free, then register the user
    if (count($errors) == 0) {
         
        // Inserting data into table
        $query = "INSERT INTO customerlogin (username, password,email,contact,picture_path) 
                  VALUES('$username', '$password','$email','$contact','$picture_path')"; 
         
        mysqli_query($db, $query);
  
        // Storing username of the logged in user,
        // in the session variable
        $_SESSION['username'] = $username;
        // Welcome message
        $_SESSION['success'] = "You have logged in";
         
        // Page on which the user will be 
        // redirected after logging in
        header('location: login-page.php'); 
    }
}
  
// User login
if (isset($_POST['login_user'])) {
     
    // Data sanitization to prevent SQL injection
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
  
    // Error message if the input field is left blank
    if (empty($username)) {
        array_push($errors, "Username is required");
    }
    if (empty($password)) {
        array_push($errors, "Password is required");
    }
  
    // Checking for the errors
    if (count($errors) == 0) {
         
        $query = "SELECT * FROM customerlogin WHERE username=
                '$username' , password='$password'AND picture_path = ?";
        $results = mysqli_query($db, $query);
  
        // $results = 1 means that one user with the
        // entered username exists
        if (mysqli_num_rows($results) == 1) {
             
            // Storing username in session variable
            $_SESSION['username'] = $username;
			$_SESSION['email'] = $username;
			$_SESSION['password'] = $password;
			$_SESSION['picture_path'] = $picture_path;
             
            // Welcome message
            $_SESSION['success'] = "You have logged in!";
             
            // Page on which the user is sent
            // to after logging in
            header('location: index.php');
        }
        else {
             
            // If the username and password doesn't match
            array_push($errors, "Username or password incorrect"); 
        }
    }
}
  
?>
