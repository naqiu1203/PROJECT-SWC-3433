
<?php

session_start();
include('Connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>HomePage || Keyboard Warrior</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- CustomCSS -->
<link href="CSS/index-page.css" rel="stylesheet" type="text/css">

<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="Script/fadein.js"></script>

<!-------------------------------------------------------------------------------->		
	
</head>
<body>


<!--NavBar------------------------------------------------------------------------>	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
<div class="container-fluid">
<!--logo and name----------------------------------------------------------------->	
	<a class="navbar-brand" href="#">
	
	<img src="upload/<?php if (isset($_SESSION['pp']))echo $_SESSION['pp'];else {echo 'dp.jpg';}?>" alt="Logo" style="width:40px;" class="rounded-pill">
	<?php
	
	if (isset($_SESSION['username'])){echo $_SESSION['username'];}
	else {
    echo '<span class="username"> KeyboardWarrior</span>';
	}
	
	?>	
    </a>
<!--Nav List---------------------------------------------------------------------->	
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
<!-------------------------------------------------------------------------------->	
		<li class="nav-item">
     	<a class="nav-link active" href="index.php">Home</a>
     	</li>
<!-------------------------------------------------------------------------------->		
     	<li class="nav-item">
        <a class="nav-link" href="http://localhost/custom-Keyboard/shop-page.php?sort=productName&sortby=ASC">Shop</a>
    	</li>
<!-------------------------------------------------------------------------------->		
<!-------------------------------------------------------------------------------->
		<?php if (isset($_SESSION['fname'])){echo '
		<li class="nav-item">
        <a class="nav-link" href="logout.php">Log Out</a>
    	</li>
		';} else {echo '<li class="nav-item">
		<a class="nav-link" href="login-page.php">Login</a>
    	</li>';}?>
		
<!-------------------------------------------------------------------------------->		
    </ul>
    </div>
</div>
</nav>

<!--Video------------------------------------------------------------------------->
<div class="container-fluid">
	
	<video class="ad" autoplay muted loop>
	<source src="Vid/keyboardVid.mp4" type="video/mp4">
	Your browser does not support the video tag.
	</video>

<!--VidCap------------------------------------------------------------------------->	
	<div class="centered">WELCOME TO <br>KEYBOARDWARRIOR<br>
	<p>Unleash Your Typing Power with KeyboardWarrior - Where Keyboards Rule the Realm!</p>
	<a href="http://localhost/custom-Keyboard/shop-page.php?sort=productName&sortby=ASC"><button class="button-59" role="button">DISCOVER</button></a>
	</div>	
</div>

<!--Top3-------------------------------------------------------------------------->
<div class="container-fluid">
<section>
	<div class="container reveal">
    <h1>GET THE LOWEST-PRICED KEYBOARD AT OUR STORE!</h1>
    
<!-------------------------------------------------------------------------------->
	<div class="row text-container"> 
    
<!-------------------------------------------------------------------------------->
	<?php
// Storing Session
$sql = "SELECT * FROM product ORDER BY price ASC LIMIT 3";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)	
{ ?>
		
		<?php
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    	?>
		
		<div class="col card" style="width:400px">
    	<img class="card-img-top" src="ProImg/<?php echo $row["image"]; ?>" alt="Card image">
    	<div class="card-body">
    	<h4 class="card-title"><?php echo $row["productName"]; ?></h4>
      	<p class="card-text"><?php echo $row["body"]; ?></p>
      	<a href="http://localhost/custom-Keyboard/shop-page.php?sort=productName&sortby=ASC" class="btn btn-primary">SHOP</a>
    	</div>
		</div>
		<?php } ?>
		<?php } ?>

	</div>
	</section>
	</div>
</div>

<!-------------------------------------------------------------------------------->
<br><br><br>
<div class="container mt-2 textblack">
<center>
<h1>Q&A</h1><br>
<p>Got Questions? We've Got Answers!</p>
</center>
	
<!-------------------------------------------------------------------------------->
	<div id="accordion">   	  
	<div class="card">
    <div class="card-header">
    <a class="btn" data-bs-toggle="collapse" href="#collapse1">Are the keyboards durable?</a>
	</div>
    	<div id="collapse1" class="collapse" data-bs-toggle="collapse">
        <div class="card-body">
        Absolutely! Our keyboards are built to withstand even the most intense gaming sessions.
        </div>
      	</div>
    </div><br>
		
<!--------------------------------------------------------------------------------> 	  
	<div class="card">
    <div class="card-header">
    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse2">
    Can I return a keyboard?
    </a>
    </div>
    	<div id="collapse2" class="collapse" data-bs-parent="#accordion">
    	<div class="card-body">
        No.
      	</div>
    	</div>
  	</div><br>
		
<!--------------------------------------------------------------------------------> 	  
	<div class="card">
    <div class="card-header">
    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse3">
    Are the keyboards customizable?
    </a>
    </div>
    	<div id="collapse3" class="collapse" data-bs-parent="#accordion">
    	<div class="card-body">
        Definitely! You can customize your keyboard with different switches, keycaps, and colors.
      	</div>
    	</div>
  	</div><br>
	
<!--------------------------------------------------------------------------------> 	  
	<div class="card">
    <div class="card-header">
    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse4">
    Do you offer warranty?
    </a>
    </div>
    <div id="collapse4" class="collapse" data-bs-parent="#accordion">
    	<div class="card-body">
        Of course! All our keyboards come with a 1-year warranty for your peace of mind.
      	</div>
    </div>
  	</div><br> 
		
<!--------------------------------------------------------------------------------> 	
	<div class="card">
    <div class="card-header">
    <a class="collapsed btn" data-bs-toggle="collapse" href="#collapse5">
    How do I contact support?
    </a>
    </div>
    	<div id="collapse5" class="collapse" data-bs-parent="#accordion">
      	<div class="card-body">
        Our support team is available 24/7 via email and phone.
      	</div>
    	</div>
  	</div><br>
		
<!--------------------------------------------------------------------------------> 	  
  	</div>
</div>
	
<!-------------------------------------------------------------------------------->
<div class="container mt-2">	
<div class="row row-cols-2">

<!-------------------------------------------------------------------------------->
<div class="col">
	<div class="card">
	<div class="card-header">Call</div>
	<div class="card-body">
    1-800-KEYBOARD
    </div>
	</div><br>
</div>
	
<!-------------------------------------------------------------------------------->	
 <div class="col">
	<div class="card">
	<div class="card-header">Email</div>
	<div class="card-body">
    info@keyboardwarrior.com
    </div>
	</div><br>
</div>
	
<!-------------------------------------------------------------------------------->	
 <div class="col">
	<div class="card">
	<div class="card-header">Find Us</div>
	<div class="card-body">
    Kuala Lumpur Malaysia
    </div>
	</div><br>
</div>

<!-------------------------------------------------------------------------------->
<div class="col">
	<div class="card">
	<div class="card-header">Type Time</div>
	<div class="card-body">
    Mon-Fri: 9am-6pm
    </div>
	</div><br>
</div>

<!-------------------------------------------------------------------------------->

</div>			
</div>

<!--Footer------------------------------------------------------------------------>
<div class="mt-5 p-4 bg-dark text-white text-center">
<p>© 2024 Keyboard Warrior. All Rights Reserved.
</p>
</div>
<!-------------------------------------------------------------------------------->	
</body>
</html>
