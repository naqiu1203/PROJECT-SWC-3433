

<!doctype html>
<html lang="en">
<head>
<title>Sign In || Welcome To Keyboard Warrior</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	
<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- CustomCSS -->
<link rel="stylesheet" type="text/css" href="CSS/signin-page.css?<?php echo time(); ?>" />
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-------------------------------------------------------------------------------->	
</head>

<body>
	
<div class="container-sm p-3 my-3 bg-white">	
	
	
	
<!--Login------------------------------------------------------------------------->    
	<h1>WELCOME TO<br> KEYBOARD WARRIOR<br></h1>
	<p>"Master art of typing with our keyboard"<br></p>
	<p>Already had an account? <a href="login-page.php">Log In Now!.</a></p>	
	
	<!--Login Form---------------------------------------------------->
	<form action="php/signup.php"	method="post"	enctype="multipart/form-data">
		<div class="input-field">
			<p>Upload Profile Picture : </p>
			<input type="file" 	name="pp" required>
        </div>
		<div class="input-field">
			<p>Full Name : </p>
            <input type="text" 
		           name="fname"
		           value="<?php echo (isset($_GET['fname']))?$_GET['fname']:"" ?>"required>
        </div>
		
        <div class="input-field">
			<p>Username : </p>
        	<input type="text" 
		           name="uname"
		           value="<?php echo (isset($_GET['uname']))?$_GET['uname']:"" ?>"required>
        </div>
		
		
        <div class="input-field">
			<p>Password : </p>
             <input type="password" 
		           name="pass" id="password" required>
        </div>
		<input type="checkbox" id="toggleVisibility">
  		<label for="toggleVisibility">Show Password</label>
                 	
        <div class="input-field button">
			<button class="button-9" type="submit">Sign In</button>
		</div>
		<?php if(isset($_GET['error'])){ ?>
    		<div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
			</div>
		    <?php } ?>

		    <?php if(isset($_GET['success'])){ ?>
    		<div class="alert alert-success" role="alert">
			  <?php echo $_GET['success']; ?>
			</div>
		    <?php } ?>
	</form>
	<!--Login Form---------------------------------------------------->
	
</div>
<script src="Script/login-page.js"></script>	
</body>
</html>