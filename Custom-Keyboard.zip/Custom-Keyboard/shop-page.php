<?php 
session_start();
include('Connection.php');

if (isset($_SESSION['id']) && isset($_SESSION['fname'])) {
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Shop || Keyboard Warrior</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- CustomCSS -->
<link href="CSS/index-page.css" rel="stylesheet" type="text/css">
<link href="CSS/shop-page.css" rel="stylesheet" type="text/css">
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="Script/fadein.js"></script>

<!-------------------------------------------------------------------------------->		
	
</head>
<body>


<!--NavBar------------------------------------------------------------------------>	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
<div class="container-fluid">
<!--logo and name----------------------------------------------------------------->	
	<a class="navbar-brand" href="#">
	
	<img src="upload/<?php if (isset($_SESSION['pp']))echo $_SESSION['pp'];else {echo 'dp.jpg';}?>" alt="Logo" style="width:40px;" class="rounded-pill">
	<?php
	
	if (isset($_SESSION['username'])){echo $_SESSION['username'];}
	else {
    echo '<span class="username"> KeyboardWarrior</span>';
	}
	
	?>	
    </a>
<!--Nav List---------------------------------------------------------------------->	
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
<!-------------------------------------------------------------------------------->	
		<li class="nav-item">
     	<a class="nav-link" href="index.php">Home</a>
     	</li>
<!-------------------------------------------------------------------------------->		
     	<li class="nav-item">
        <a class="nav-link active" href="http://localhost/custom-Keyboard/shop-page.php?sort=productName&sortby=ASC">Shop</a>
    	</li>
<!-------------------------------------------------------------------------------->		
<?php if (isset($_SESSION['fname'])){echo '
		<li class="nav-item">
        <a class="nav-link" href="logout.php">Log Out</a>
    	</li>
		';} else {echo '<li class="nav-item">
		<a class="nav-link" href="login-page.php">Login</a>
    	</li>';}?>
<!-------------------------------------------------------------------------------->		
    </ul>
    </div>
</div>
</nav>


<?php

// Storing Session
$sql = "SELECT * FROM product ORDER BY id DESC LIMIT 3";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)	
{ ?>
<div class="container p-5 my-5 text-black">
<h1>List Of Keyboard</h1>


<h4>Newest Keyboard</h4>
<div class="flex-container">

<?php
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    	?>		
	
  <div class="product-card">
    <img src="ProImg/<?php echo $row["image"]; ?>" alt="Product Name">
    <h3 class="product-title"><?php echo $row["productName"]; ?></h3>
    <p class="product-description"><?php echo $row["body"]; ?></p>
    <p class="product-price"><a href="ThankYou.php?customerid=<?php echo $_SESSION['id'];?>&productid=<?php echo $row['id']; ?>" class="btn btn-primary">RM <?php echo $row["price"]; ?></a></p>
  </div>
		<?php } ?>
		<?php } ?>
	
	
	
</div>
</div>
	

<div class="container p-5 my-5 text-black">

	<?php
// Storing Session
	
if ($_GET['sort']=="-" && $_GET['sortby']=="-"){ 
  $sql= "SELECT * FROM product";
  	
}
 	else{
		$sql= "SELECT * FROM product ORDER BY ".$_GET['sort']." ".$_GET['sortby'];
		
	}
$result = mysqli_query($conn, $sql);	
if (mysqli_num_rows($result) > 0)	
{ ?>
<h4>ALL(<?php echo mysqli_num_rows($result) ?>)</h4>
<form id="sortform">
<select id="sort" name="sort" form="sortform">
	<option value="-">-sort product by-</option>
  	<option value="productName">Name</option>
  	<option value="price">Price</option>
  	<option value="id">Date Added</option>
	</select>

<select id="sortby" name="sortby" form="sortform">
  <option value="-">-sort by-</option>
  <option value="ASC" type="submit">Ascending</option>
  <option value="DESC">Descending</option></select>
	<input type="submit" value="Sort">
</form>


<div class="flex-container">



<?php
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    	?>		
	
  <div class="product-card">
    <img src="ProImg/<?php echo $row["image"]; ?>" alt="Product Name">
    <h3 class="product-title"><?php echo $row["productName"]; ?></h3>
    <p class="product-description"><?php echo $row["body"]; ?></p>
    <p class="product-price"><a href="ThankYou.php?customerid=<?php echo $_SESSION['id'];?>&productid=<?php echo $row['id']; ?>" class="btn btn-primary">RM <?php echo $row["price"]; ?></a></p>
  	
	
	</div>
		<?php } ?>
		<?php } ?>
	
	
	
</div>
</div>

	
	
</body>
</html>
<?php }else {
	header("Location: login-page.php");
	exit;
} ?>