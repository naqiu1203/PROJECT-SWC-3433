<?php 
session_start();
include('../Connection.php');

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>OrderDetail || Keyboard Warrior</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- CustomCSS -->
<link href="../CSS/index-page.css" rel="stylesheet" type="text/css">
<link href="../CSS/shop-page.css" rel="stylesheet" type="text/css">
<link href="../CSS/ordertable.css" rel="stylesheet" type="text/css">	
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../Script/fadein.js"></script>

<!-------------------------------------------------------------------------------->		
	
</head>
<body>


<!--NavBar------------------------------------------------------------------------>	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
<div class="container-fluid">
<!--logo and name----------------------------------------------------------------->	
	<a class="navbar-brand" href="#">
<span class="username"> Welcome</span>
	<?php
	
	if (isset($_SESSION['username'])){echo $_SESSION['username'];}
	else {
    echo '<span class="username"> KeyboardWarrior</span>';
	}
	
	?>	
    </a>
<!--Nav List---------------------------------------------------------------------->	
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
<!-------------------------------------------------------------------------------->	
		
<!-------------------------------------------------------------------------------->		
     	<li class="nav-item">
        <a class="nav-link" href="Adminshop-page.php?sort=productName&sortby=ASC">Home</a>
    	</li>

<!-------------------------------------------------------------------------------->		
    	<li class="nav-item">
		<a class="nav-link" href="productadd.php">Add New Product</a>
    	</li>
<!-------------------------------------------------------------------------------->

		<li class="nav-item">
		<a class="nav-link active" href="OrderPage.php">Order Detail</a>
    	</li>
		
<!-------------------------------------------------------------------------------->

		<li class="nav-item">
		<a class="nav-link" href="logout.php">Logout</a>
    	</li>
<!-------------------------------------------------------------------------------->		
		
		<li class="nav-item">
		<a class="nav-link" href="http://localhost/custom-Keyboard/login-page.php">View Website</a>
    	</li>
<!-------------------------------------------------------------------------------->		
    </ul>
    </div>
</div>
</nav>

<div class="container-sm p-3 my-3"><center>		
<table class="comicGreen">
<thead>
<tr>
<th>OrderID</th>
<th>CustomerID</th>
<th>Customer 	Name</th>
<th>ProductID</th>
<th>Product Name</th>
<th>Product Price</th>
</tr>
</thead>
<?php

// Storing Session
$sql = "SELECT * FROM orderdetail ORDER BY id ASC";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)	
{ ?>
<?php
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    	?>		
<tbody>
<tr>
<td><?php echo $row["id"]; ?></td>
<td><?php echo $row["customerid"]; ?></td>
<td><?php echo $row["customername"]; ?></td>
<td><?php echo $row["productid"]; ?></td>
<td><?php echo $row["productname"]; ?></td>
<td>RM <?php echo $row["productprice"]; ?></td>
</tr>
</tbody>
<?php }?>
<?php }?>
</table>
</center>
</div>	
	
	
</body>
</html>

<?php }else {
	header("Location: Adminlogin-page.php");
	exit;
} ?>