-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2024 at 10:22 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customkeyboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `productid` int(11) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `productprice` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`id`, `customerid`, `customername`, `productid`, `productname`, `productprice`) VALUES
(1, 7, 'CustomerFullName', 7, 'GGA', '123.99'),
(5, 6, 'Gabumon', 7, 'GGA', '123.99'),
(6, 5, 'AdminFullName', 7, 'GGA', '123.99'),
(7, 7, 'CustomerFullName', 7, 'GGA', '123.99'),
(8, 5, 'AdminFullName', 7, 'GGA', '123.99'),
(9, 5, 'AdminFullName', 7, 'GGA', '123.99'),
(10, 5, 'AdminFullName', 7, 'GGA', '123.99'),
(11, 7, 'CustomerFullName', 7, 'GGA', '123.99'),
(12, 6, 'Gabumon', 7, 'GGA', '123.99'),
(13, 7, 'CustomerFullName', 7, 'GGA', '123.99'),
(14, 7, 'CustomerFullName', 6, 'GGV12', '127.88'),
(15, 7, 'CustomerFullName', 5, 'NovaFlex', '120.99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
