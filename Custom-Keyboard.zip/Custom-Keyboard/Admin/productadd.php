

<!doctype html>
<html lang="en">
<head>
<title>Add New Product</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	
<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- CustomCSS -->
<link rel="stylesheet" type="text/css" href="CSS/productadd.css?<?php echo time(); ?>" />
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-------------------------------------------------------------------------------->	
</head>

<body>
	
<div class="container-sm p-3 my-3 bg-white">	
	
	
	
<!--Login------------------------------------------------------------------------->    
	<h1>ADD NEW PRODUCT</h1>
	
	<!--Login Form---------------------------------------------------->
	<form action="php/productadd.php"	method="post"	enctype="multipart/form-data">
		<div class="input-field">
			<p>Upload Product Picture : </p>
			<input type="file" 	name="image" required>
        </div>
		<div class="input-field">
			<p>Product Name : </p>
            <input type="text" 
		           name="pname"
		           value="<?php echo (isset($_GET['pname']))?$_GET['pname']:"" ?>"required>
        </div>
		
        <div class="input-field">
			<p>Detail : </p>
        	<input type="text" 
		           name="dtail"
		           value="<?php echo (isset($_GET['dtail']))?$_GET['dtail']:"" ?>"required>
        </div>
		
		
        <div class="input-field">
			<p>Price : </p>
             <input type="text" 
		           name="rice" 
					value="<?php echo (isset($_GET['rice']))?$_GET['rice']:"" ?>"required>
        </div>
                 	
        <div class="input-field button">
			<button class="button-9" type="submit">ADD</button>
		</div>
		<?php if(isset($_GET['error'])){ ?>
    		<div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
			</div>
		    <?php } ?>

		    <?php if(isset($_GET['success'])){ ?>
    		<div class="alert alert-success" role="alert">
			  <?php echo $_GET['success']; ?>
			</div>
		    <?php } ?>
	</form>
	<!--Login Form---------------------------------------------------->
	
</div>
	
</body>
</html>