<?php 
session_start();
include('Connection.php');

if (isset($_SESSION['id']) && isset($_SESSION['username'])) {
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Shop || Keyboard Warrior</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- CustomCSS -->
<link href="CSS/index-page.css" rel="stylesheet" type="text/css">
<link href="CSS/shop-page.css" rel="stylesheet" type="text/css">
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="Script/fadein.js"></script>

<!-------------------------------------------------------------------------------->		
	
</head>
<body>


<!--NavBar------------------------------------------------------------------------>	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
<div class="container-fluid">
<!--logo and name----------------------------------------------------------------->	
	<a class="navbar-brand" href="#">
<span class="username"> Welcome</span>
	<?php
	
	if (isset($_SESSION['username'])){echo $_SESSION['username'];}
	else {
    echo '<span class="username"> KeyboardWarrior</span>';
	}
	
	?>	
    </a>
<!--Nav List---------------------------------------------------------------------->	
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
<!-------------------------------------------------------------------------------->	
		
<!-------------------------------------------------------------------------------->		
     	<li class="nav-item">
        <a class="nav-link active" href="Adminshop-page.php?sort=productName&sortby=ASC">Home</a>
    	</li>

<!-------------------------------------------------------------------------------->		
    	<li class="nav-item">
		<a class="nav-link" href="productadd.php">Add New Product</a>
    	</li>
<!-------------------------------------------------------------------------------->

		<li class="nav-item">
		<a class="nav-link" href="OrderPage.php">Order Detail</a>
    	</li>

<!-------------------------------------------------------------------------------->

		<li class="nav-item">
		<a class="nav-link" href="logout.php">Logout</a>
    	</li>
<!-------------------------------------------------------------------------------->		
		
		<li class="nav-item">
		<a class="nav-link" href="http://localhost/custom-Keyboard/login-page.php">View Website</a>
    	</li>
<!-------------------------------------------------------------------------------->		
    </ul>
    </div>
</div>
</nav>

<div class="container p-5 my-5 text-black">
	<?php
// Storing Session
	
if ($_GET['sort']=="-" && $_GET['sortby']=="-"){ 
  $sql= "SELECT * FROM product";
  	
}
 	else{
		$sql= "SELECT * FROM product ORDER BY ".$_GET['sort']." ".$_GET['sortby'];
		
	}
$result = mysqli_query($conn, $sql);	
if (mysqli_num_rows($result) > 0)	
{ ?>
<h4>ALL(<?php echo mysqli_num_rows($result) ?>)</h4>
<form id="sortform">
<select id="sort" name="sort" form="sortform">
	<option value="-">-sort product by-</option>
  	<option value="productName">Name</option>
  	<option value="price">Price</option>
  	<option value="id">Date Added</option>
	</select>

<select id="sortby" name="sortby" form="sortform">
  <option value="-">-sort by-</option>
  <option value="ASC" type="submit">Ascending</option>
  <option value="DESC">Descending</option></select>
	<input type="submit" value="Sort">
</form>


<div class="flex-container">



<?php
      //OUTPUT DATA OF EACH ROW
      while($row = mysqli_fetch_assoc($result)){
    	?>		
	
  <div class="product-card">
    <img src="../ProImg/<?php echo $row["image"]; ?>" alt="Product Name">
    <h3 class="product-title"><?php echo $row["productName"]; ?></h3>
    <p class="product-description"><?php echo $row["body"]; ?></p>
	<p class="product-description"> RM <?php echo $row["price"]; ?></p>
    <a class="btn btn-warning" href="productdelete.php?id=<?php echo $row["id"]; ?>" >Delete</a>
	<a class="btn btn-success" href="productupdate-form.php?id=<?php echo $row["id"]; ?>" >Update</a>  
	  </p>
  	
	
	</div>
		<?php } ?>
		<?php } ?>
	
	
	
</div>
</div>

	
	
</body>
</html>
<?php }else {
	header("Location: Adminlogin-page.php");
	exit;
} ?>