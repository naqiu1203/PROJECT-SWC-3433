
<!doctype html>
<html lang="en">
<head>
<title>Admin Login</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	
<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- CustomCSS -->
<link rel="stylesheet" type="text/css" href="CSS/login-page.css?<?php echo time(); ?>" />
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-------------------------------------------------------------------------------->	
</head>

<body>
	
<div class="container-sm p-5 my-5">	
	
	
	<div class="row">
<!--Login------------------------------------------------------------------------->    
	<div class="col-sm-7 p-3">
	<h1>ADMIN LOGIN</h1>
	<p>"Control art of typing with our keyboard"<br></p>
	
	
	<!--Login Form---------------------------------------------------->
	<form action="php/Adminlogin.php" method="POST">
                    <div class="input-field">
						<p>Username : </p>
                        <input type="text" placeholder="Enter your username" name="uname"
		           		value="<?php echo (isset($_GET['uname']))?$_GET['uname']:"" ?>"required>
                    </div>
		
		
		
                    <div class="input-field">
						<p>Password : </p>
                        <input type="password" 
		           name="pass" id="password" placeholder="Enter your password"required>
                    </div>
					<input type="checkbox" id="toggleVisibility">
  					<label for="toggleVisibility">Show Password</label>
                 	
                    <div class="input-field button">
						              <button class="button-9" type="submit">Login</button>
					
                        
						
                    </div>
					<?php if(isset($_GET['error'])){ ?>
    		<div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
			</div>
		    <?php } ?> 
						
						
                </form>
	<!--Login Form---------------------------------------------------->
	</div>
<!-------------------------------------------------------------------------------->

	<div class="col-sm-5">
		
	<!-- Carousel -->
	<div id="login-cara" class="carousel slide" data-bs-ride="carousel">
 
  <!-- The slideshow/carousel -->
  	<div class="carousel-inner">
    	<div class="carousel-item active">
      		<img class="imgc" src="../Img/photo1.jpg" alt="img1" class="d-block">
			<div class="carousel-caption">
    			<h3>Working with text</h3>
    			<p>Ctrl+X: Cut the selected text.<br>
				  	 Ctrl+C: Copy the selected text.<br>
				  	 Ctrl+V: Paste the copied or cut text.<br>
				  	 Ctrl+A: Select all text on the page or in the active window.</p>
			</div>
    	</div>
    	<div class="carousel-item">
      		<img class="imgc" src="../Img/photo2.jpg" alt="img2" class="d-block" >
			<div class="carousel-caption">
    			<h3>Working with files and applications</h3>
    			<p>Ctrl+N: Create a new file.<br>
					Ctrl+O: Open an existing file.<br>
					Ctrl+P: Print an open file.<br>
					Ctrl+S: Save the current file</p>
			</div>
    	</div>
    	<div class="carousel-item">
      		<img class="imgc" src="../Img/photo3.jpg" alt="img3" class="d-block">
			<div class="carousel-caption">
    			<h3>Internet shortcuts</h3>
    			<p>Ctrl+D: Bookmark the current page.<br>
					Ctrl+B: View bookmarks.<br>
					Ctrl+H: View browsing history.<br>
					Ctrl+J: View downloads.</p>
			</div>
    	</div>
  	</div>
  
</div>		
		
		
	</div>
  	</div>
</div>
<script src="Script/Adminlogin-page.js"></script>	
</body>
</html>