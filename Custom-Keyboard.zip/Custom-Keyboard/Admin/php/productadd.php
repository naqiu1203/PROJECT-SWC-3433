<?php 

if(isset($_POST['pname']) && 
   isset($_POST['dtail']) &&  
   isset($_POST['rice'])){

    include "../db_conn.php";

    $pname = $_POST['pname'];
    $dtail = $_POST['dtail'];
    $rice = $_POST['rice'];

    $data = "pname=".$pname."&dtail=".$dtail."&rice=".$rice;
    
    if (empty($pname)) {
    	$em = "Product Name is required";
    	header("Location: ../productadd.php?error=$em&$data");
	    exit;
    }else if(empty($dtail)){
    	$em = "Detail is required";
    	header("Location: ../productadd.php?error=$em&$data");
	    exit;
    }else if(empty($rice)){
    	$em = "Price is required";
    	header("Location: ../productadd.php?error=$em&$data");
	    exit;
    }else {
      

      if (isset($_FILES['image']['name']) AND !empty($_FILES['image']['name'])) {
         
         
         $img_name = $_FILES['image']['name'];
         $tmp_name = $_FILES['image']['tmp_name'];
         $error = $_FILES['image']['error'];
         
         if($error === 0){
            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_to_lc = strtolower($img_ex);

            $allowed_exs = array('jpg', 'jpeg', 'png');
            if(in_array($img_ex_to_lc, $allowed_exs)){
               $new_img_name = uniqid($uname, true).'.'.$img_ex_to_lc;
               $img_upload_path = '../../ProImg/'.$new_img_name;
               move_uploaded_file($tmp_name, $img_upload_path);

               // Insert into Database
               $sql = "INSERT INTO product(productName, body, price, image) 
                 VALUES(?,?,?,?)";
               $stmt = $conn->prepare($sql);
               $stmt->execute([$pname, $dtail, $rice, $new_img_name]);

               header("Location: ../productadd.php?success=Your account has been created successfully");
                exit;
            }else {
               $em = "You can't upload files of this type";
               header("Location: ../productadd.php?error=$em&$data");
               exit;
            }
         }else {
            $em = "unknown error occurred!";
            header("Location: ../productadd.php?error=$em&$data");
            exit;
         }

        
      }else {
       	$sql = "INSERT INTO product(productName, body, price) 
       	        VALUES(?,?,?)";
       	$stmt = $conn->prepare($sql);
       	$stmt->execute([$pname, $dtail, $rice]);

       	header("Location: ../productadd.php?success=Your account has been created successfully");
   	    exit;
      }
    }


}else {
	header("Location: ../productadd.php?error=error");
	exit;
}
