<?php
session_start();
	include('Connection.php');
	$id=$_GET['id'];
 
	$productName=$_POST['productName'];
	$body=$_POST['body'];
	$price=$_POST['price'];
 
	mysqli_query($conn,"update `product` set productName='$productName', body='$body' , price='$price' where id='$id'");
	mysqli_close($conn);

	header('Location: Adminshop-page.php?sort=productName&sortby=ASC');
?>
