<?php
session_start();
include('Connection.php');
	$id=$_GET['id'];
	$query=mysqli_query($conn,"select * from `product` where id='$id'");
	$row=mysqli_fetch_array($query);
?>


<!doctype html>
<html lang="en">
<head>
<title>Add New Product</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	
<!-------------------------------------------------------------------------------->	
<!--CSS -->
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- CustomCSS -->
<link rel="stylesheet" type="text/css" href="CSS/productadd.css?<?php echo time(); ?>" />
<!-------------------------------------------------------------------------------->
<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-------------------------------------------------------------------------------->	
</head>

<body>
	
<div class="container-sm p-3 my-3 bg-white">	

	<h2>Edit</h2>
	
	<form method="post" action="productupdate.php?id=<?php echo $id; ?>">
		<div class="input-field">
		<p>Product Name : </p>
		<input type="text" name="productName"
		value="<?php echo $row['productName']; ?>"required> </div>
		
		<div class="input-field">
		<p>Detail : </p>
        <input type="text"  name="body" value="<?php echo $row['body']; ?>"required>
        </div>
		
		<div class="input-field">
		<p>price : </p>
        <input type="text"  name="price" value="<?php echo $row['price']; ?>"required>
        </div>
		
		<div class="input-field button">
		<button class="button-9" type="submit" name="submit" >UPDATE</button>
		</div>
		
		<a href="http://localhost/custom-Keyboard/Adminshop-page.php?sort=productName&sortby=ASC">Back</a>
	
	</form>
	</div>
</body>
</html>